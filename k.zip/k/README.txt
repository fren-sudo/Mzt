Kullanım:

1) Bu dosyaları app.py ile aynı klasöre koy.
2) Termux'ta çalıştır:

python fix_app_py.py

Gerekirse özel yol ver:
python fix_app_py.py /storage/emulated/0/k/app.py

Sonra:
python app.py
