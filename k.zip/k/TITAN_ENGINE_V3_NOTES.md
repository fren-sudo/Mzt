# FIRATFLIX TITAN ENGINE V3

Bu sürümde:
- Player buffering/retry loop azaltıldı
- /proxy ve /proxy_stream güçlendirildi
- Nested proxy engeli eklendi
- Mixed content için url_helpers.js eklendi
- Kırık logo kaynakları primary source olmaktan çıkarıldı
- continue.js spamı azaltıldı
- TV navigation referans dosyaları eklendi (`static/js/fxm/`)
- player.html ve base.html favicon / helper script zinciri düzeltildi
