
from pathlib import Path
import re
import sys

APP = Path("app.py")
if len(sys.argv) > 1:
    APP = Path(sys.argv[1])

if not APP.exists():
    raise SystemExit(f"app.py bulunamadı: {APP}")

text = APP.read_text(encoding="utf-8", errors="ignore")

# 1) Kırılan image_of / choose_best_artwork bloğunu düzelt
pattern = re.compile(
    r"def image_of\(item\):.*?return \"https://via\.placeholder\.com/400x600\?text=No\+Image\"\n",
    re.S
)

replacement = """def image_of(item):
    return choose_best_artwork(item)

def choose_best_artwork(item):
    for key in ('stream_icon', 'cover', 'cover_big', 'movie_image', 'poster', 'backdrop_path', 'logo'):
        if isinstance(item, dict):
            value = item.get(key)
            if value:
                return normalize_image_url(value)

    return "https://via.placeholder.com/400x600?text=No+Image"
"""

new_text, count = pattern.subn(replacement, text, count=1)

# 2) Eğer yukarıdaki blok bozuk olduğu için regex yakalayamazsa, daha kaba onarım uygula
if count == 0:
    alt = re.compile(
        r"def image_of\(item\):\s*(?:\n|\r\n)+\s*def choose_best_artwork\(item\):\s*(?:\n|\r\n)+\s*for key in .*?return \"https://via\.placeholder\.com/400x600\?text=No\+Image\"",
        re.S
    )
    new_text, count = alt.subn(replacement.rstrip(), text, count=1)

# 3) Hâlâ bulamazsa, elle bulup sabit bloğu ekle
if count == 0:
    idx = text.find("def image_of(item):")
    if idx != -1:
        # En yakın sonraki fonksiyon ya da route başlangıcına kadar kırp
        next_markers = []
        for m in ["\ndef normalize_", "\n@app.route", "\ndef strict_http_url", "\ndef tmdb_", "\ndef build_"]:
            j = text.find(m, idx + 1)
            if j != -1:
                next_markers.append(j)
        end = min(next_markers) if next_markers else idx + 1000
        new_text = text[:idx] + replacement + "\n" + text[end:]
        count = 1

if count == 0:
    raise SystemExit("Kırık blok bulunamadı. app.py çok farklı olabilir.")

# 4) Güvenli çalıştırma ayarı
new_text = re.sub(
    r"if __name__ == ['\"]__main__['\"]:\s*\n\s*app\.run\(.*?\)",
    "if __name__ == '__main__':\n    app.run(host='0.0.0.0', port=5001, threaded=True, debug=False)",
    new_text,
    flags=re.S
)

APP.write_text(new_text, encoding="utf-8")
print(f"Düzeltildi: {APP}")
