
import os
import random
import re
from urllib.parse import quote, urlparse, urljoin

import requests
from requests.exceptions import ChunkedEncodingError, ConnectionError as RequestsConnectionError
from flask import Flask, render_template, request, jsonify, Response, stream_with_context, send_from_directory, redirect

from services.cache import TTLCache
from core.provider_engine import ProviderEngine
from providers.xtream import XtreamProvider
from providers.tmdb import TMDBProvider
from providers.tmdb_real import TMDBProvider as TMDBReal
from services.continue_watch import save_progress, list_items

app = Flask(__name__)

BASE_URL = os.getenv('IPTV_BASE_URL', 'http://udhiptv.shop:8080').rstrip('/')
USER = os.getenv('IPTV_USER', 'gkn7027')
PASS = os.getenv('IPTV_PASS', '5228c0b8239768e8')

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Connection': 'keep-alive'
})

cache = TTLCache(ttl=180)
providers = ProviderEngine()

def safe_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

def newest_key(item):
    for k in ('added', 'created', 'date', 'timestamp'):
        if item.get(k):
            return safe_int(item.get(k), 0)
    for k in ('stream_id', 'series_id', 'id'):
        if item.get(k):
            return safe_int(item.get(k), 0)
    return 0

def strict_http_url(target: str) -> bool:
    try:
        p = urlparse(target)
        return p.scheme in ('http', 'https')
    except Exception:
        return False


def normalize_image_url(url: str) -> str:
    if not url:
        return ''
    url = url.strip()
    if url.startswith('//'):
        return 'https:' + url
    if url.lower().startswith('http://'):
        return 'https://' + url[7:]
    return url


def swap_video_extension(url: str) -> str:
    if not url:
        return ''
    if url.lower().endswith('.mp4'):
        return url[:-4] + '.mkv'
    if url.lower().endswith('.mkv'):
        return url[:-4] + '.mp4'
    return ''

def image_of(item):
    return choose_best_artwork(item)

def choose_best_artwork(item):
    for key in ('stream_icon', 'cover', 'cover_big', 'movie_image', 'poster', 'backdrop_path', 'logo'):
        if isinstance(item, dict):
            value = item.get(key)
            if value:
                return normalize_image_url(value)

    return "https://via.placeholder.com/400x600?text=No+Image"
    
    
    return 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><rect width="100%" height="100%" fill="%23111"/><text x="50%" y="50%" fill="%23fff" font-family="Segoe UI, Arial" font-size="26" dominant-baseline="middle" text-anchor="middle">Resim Yok</text></svg>'
    raw_url = (
        item.get('stream_icon')
        or item.get('cover')
        or item.get('cover_big')
        or 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><rect width="100%" height="100%" fill="%23111"/><text x="50%" y="50%" fill="%23fff" font-family="Segoe UI, Arial" font-size="26" dominant-baseline="middle" text-anchor="middle">Resim Yok</text></svg>'
    )
    # Convert TMDB image URLs or other http resources to https for mixed content safety
    return normalize_image_url(raw_url)

def build_stream_url(mode: str, item_id: str, ext: str = 'mp4'):
    item_id = str(item_id)
    if mode == 'live':
        return f"{BASE_URL}/live/{USER}/{PASS}/{item_id}.ts"
    if mode == 'series':
        return f"{BASE_URL}/series/{USER}/{PASS}/{item_id}.{ext or 'mp4'}"
    return f"{BASE_URL}/movie/{USER}/{PASS}/{item_id}.{ext or 'mp4'}"

def normalize_vod_item(item):
    sid = str(item.get('stream_id') or item.get('id') or '')
    ext = item.get('container_extension', 'mp4')
    return {
        'id': sid,
        'title': item.get('name') or item.get('title') or 'İsimsiz',
        'img': image_of(item),
        'desc': item.get('description') or item.get('plot') or item.get('info') or item.get('overview') or '',
        'year': str(item.get('year') or '')[:4],
        'rating': item.get('rating') or item.get('imdb_rating') or item.get('rating_5') or '',
        'genre': item.get('genre') or item.get('category_name') or '',
        'actors': item.get('actors') or item.get('cast') or item.get('director') or '',
        'mode': 'movies',
        'url': build_stream_url('movies', sid, ext),
    }

def normalize_live_item(item):
    sid = str(item.get('stream_id') or item.get('id') or '')
    return {
        'id': sid,
        'title': item.get('name', 'Kanal'),
        'img': image_of(item),
        'desc': item.get('epg_channel_id') or 'Canlı yayın',
        'year': '',
        'rating': '',
        'genre': item.get('category_name') or '',
        'mode': 'live',
        'url': build_stream_url('live', sid, 'ts'),
    }

def normalize_series_item(item):
    sid = str(item.get('series_id') or item.get('id') or '')
    return {
        'id': sid,
        'title': item.get('name') or item.get('title') or 'Dizi',
        'img': image_of(item),
        'desc': item.get('plot') or item.get('description') or item.get('info') or item.get('overview') or '',
        'year': str(item.get('year') or '')[:4],
        'rating': item.get('rating') or item.get('imdb_rating') or item.get('rating_5') or '',
        'genre': item.get('genre') or item.get('category_name') or '',
        'actors': item.get('actors') or item.get('cast') or item.get('director') or '',
        'mode': 'series',
        'url': '',
    }

def get_data(action: str, extra: str = '', ttl: int = 180):
    key = f'{action}:{extra}'
    cached = cache.get(key)
    if cached is not None:
        return cached
    url = f"{BASE_URL}/player_api.php?username={USER}&password={PASS}&action={action}{extra}"
    try:
        r = session.get(url, timeout=20)
        r.raise_for_status()
        data = r.json()
        cache.set(key, data, ttl=ttl)
        return data
    except Exception as e:
        print('API ERROR', action, e)
        return []

providers.register('xtream', XtreamProvider(get_data))
providers.register('tmdb', TMDBProvider())
xtream = providers.get('xtream')

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/')
def landing():
    raw_vod = xtream.vod_streams()
    raw_series = xtream.series_streams()
    raw_live = xtream.live_streams()

    if isinstance(raw_vod, list):
        raw_vod = sorted(raw_vod, key=newest_key, reverse=True)
    if isinstance(raw_series, list):
        raw_series = sorted(raw_series, key=newest_key, reverse=True)
    if isinstance(raw_live, list):
        raw_live = sorted(raw_live, key=newest_key, reverse=True)

    hero_pool = [normalize_vod_item(x) for x in raw_vod[:30]]
    hero_items = random.sample(hero_pool, 8) if len(hero_pool) > 8 else hero_pool
    latest_movies = [normalize_vod_item(x) for x in raw_vod[:18]]
    trending_movies = [normalize_vod_item(x) for x in raw_vod[18:36]]
    popular_series = [normalize_series_item(x) for x in raw_series[:18]]
    live_channels = [normalize_live_item(x) for x in raw_live[:18]]

    return render_template(
        'landing.html',
        hero_items=hero_items,
        latest_movies=latest_movies,
        trending_movies=trending_movies,
        popular_series=popular_series,
        live_channels=live_channels,
    )

@app.route('/lampa')
def lampa_redirect_trailing():
    return redirect('/lampa/')

@app.route('/lampa/')
def lampa_index():
    source = request.args.get('source', 'xtream').lower()
    query_title = request.args.get('title', '').strip()
    page = safe_int(request.args.get('page', 1), 1)
    component = request.args.get('component', 'main')

    # TMDB formattan gelen başlıkta " - TMDB" bulunuyorsa temizle
    if source == 'tmdb' and query_title.lower().endswith(' - tmdb'):
        query_title = query_title[:-7].strip()

    raw_vod = xtream.vod_streams()
    raw_series = xtream.series_streams()
    raw_live = xtream.live_streams()

    if isinstance(raw_vod, list):
        raw_vod = sorted(raw_vod, key=newest_key, reverse=True)
    if isinstance(raw_series, list):
        raw_series = sorted(raw_series, key=newest_key, reverse=True)
    if isinstance(raw_live, list):
        raw_live = sorted(raw_live, key=newest_key, reverse=True)

    hero_pool = [normalize_vod_item(x) for x in raw_vod[:30]]
    hero_items = random.sample(hero_pool, 8) if len(hero_pool) > 8 else hero_pool
    latest_movies = [normalize_vod_item(x) for x in raw_vod[:18]]
    trending_movies = [normalize_vod_item(x) for x in raw_vod[18:36]]
    popular_series = [normalize_series_item(x) for x in raw_series[:18]]
    live_channels = [normalize_live_item(x) for x in raw_live[:18]]

    tmdb_results = []
    tmdb_query = ''

    if source == 'tmdb' and query_title:
        tmdb_query = query_title
        try:
            tmdb_data = TMDBReal().search(query_title)
            if tmdb_data:
                tmdb_results.append({
                    'id': query_title,
                    'title': query_title,
                    'img': tmdb_data.get('poster') or tmdb_data.get('backdrop') or '',
                    'desc': tmdb_data.get('overview', ''),
                    'year': '',
                    'rating': tmdb_data.get('rating', ''),
                    'genre': '',
                    'mode': 'movies',
                    'url': tmdb_data.get('poster') or tmdb_data.get('backdrop') or '',
                })
        except Exception:
            tmdb_results = []

    return render_template(
        'lampa_home.html',
        hero_items=hero_items,
        latest_movies=latest_movies,
        trending_movies=trending_movies,
        popular_series=popular_series,
        live_channels=live_channels,
        tmdb_results=tmdb_results,
        tmdb_query=tmdb_query,
        source=source,
        component=component,
        page=page,
    )

@app.route('/lampa/<path:filename>')
def lampa_static(filename):
    return send_from_directory(os.path.join(app.root_path, 'lampa'), filename)

@app.route('/api/lampa/config')
def api_lampa_config():
    return jsonify({
        'lampa': True,
        'base_url': BASE_URL,
        'proxy': '/proxy',
        'sticky': '/legacy',
        'providers': providers.names(),
    })

@app.route('/legacy')
def legacy_landing():
    raw_vod = xtream.vod_streams()
    raw_series = xtream.series_streams()
    raw_live = xtream.live_streams()

    if isinstance(raw_vod, list):
        raw_vod = sorted(raw_vod, key=newest_key, reverse=True)
    if isinstance(raw_series, list):
        raw_series = sorted(raw_series, key=newest_key, reverse=True)
    if isinstance(raw_live, list):
        raw_live = sorted(raw_live, key=newest_key, reverse=True)

    hero_pool = [normalize_vod_item(x) for x in raw_vod[:30]]
    hero_items = random.sample(hero_pool, 8) if len(hero_pool) > 8 else hero_pool
    latest_movies = [normalize_vod_item(x) for x in raw_vod[:18]]
    trending_movies = [normalize_vod_item(x) for x in raw_vod[18:36]]
    popular_series = [normalize_series_item(x) for x in raw_series[:18]]
    live_channels = [normalize_live_item(x) for x in raw_live[:18]]

    return render_template(
        'landing.html',
        hero_items=hero_items,
        latest_movies=latest_movies,
        trending_movies=trending_movies,
        popular_series=popular_series,
        live_channels=live_channels,
    )

def get_home_data():
    raw_vod = xtream.vod_streams()
    raw_series = xtream.series_streams()
    raw_live = xtream.live_streams()
    if isinstance(raw_vod, list):
        raw_vod = sorted(raw_vod, key=newest_key, reverse=True)
    if isinstance(raw_series, list):
        raw_series = sorted(raw_series, key=newest_key, reverse=True)
    if isinstance(raw_live, list):
        raw_live = sorted(raw_live, key=newest_key, reverse=True)

    return {
        'hero_items': [normalize_vod_item(x) for x in raw_vod[:8]],
        'latest_movies': [normalize_vod_item(x) for x in raw_vod[:18]],
        'trending_movies': [normalize_vod_item(x) for x in raw_vod[18:36]],
        'popular_series': [normalize_series_item(x) for x in raw_series[:18]],
        'live_channels': [normalize_live_item(x) for x in raw_live[:18]],
    }

@app.route('/api/home')
def api_home():
    return jsonify(get_home_data())

@app.route('/api/lampa/home')
def api_lampa_home():
    return jsonify(get_home_data())


def find_item_by_mode(mode, item_id):
    if mode == 'live':
        streams = xtream.live_streams()
        items = [normalize_live_item(x) for x in streams]
    elif mode == 'series':
        streams = xtream.series_streams()
        items = [normalize_series_item(x) for x in streams]
    else:
        streams = xtream.vod_streams()
        items = [normalize_vod_item(x) for x in streams]

    for item in items:
        if str(item.get('id')) == str(item_id):
            return item
    return None


@app.route('/item/<mode>/<item_id>')
def item_detail(mode, item_id):
    item = find_item_by_mode(mode, item_id)
    if not item:
        return 'İçerik bulunamadı', 404

    item_details = item.copy()
    series_meta = None

    if mode == 'series':
        info = xtream.series_info(item_id)
        if isinstance(info, dict):
            item_details['desc'] = item_details.get('desc') or info.get('plot') or info.get('description') or info.get('overview', '')
            item_details['genre'] = item_details.get('genre') or info.get('genre') or info.get('category_name', '')
            item_details['year'] = item_details.get('year') or str(info.get('year') or '')[:4]
            item_details['rating'] = item_details.get('rating') or info.get('rating') or info.get('imdb_rating', '')
            item_details['actors'] = item_details.get('actors') or info.get('actors') or info.get('cast') or ''

            episodes = info.get('episodes', {})
            seasons = []
            for s in sorted(episodes.keys(), key=lambda x: safe_int(str(x), 99999)):
                season_eps = []
                for ep in episodes.get(s, []):
                    eid = str(ep.get('id') or ep.get('episode_id') or '')
                    ext = ep.get('container_extension', 'mp4')
                    season_eps.append({
                        'id': eid,
                        'num': str(ep.get('episode_num') or ''),
                        'title': ep.get('title') or f'Bölüm {ep.get("episode_num") or ""}'.strip(),
                        'desc': ep.get('description') or ep.get('plot') or '',
                        'url': build_stream_url('series', eid, ext),
                    })
                seasons.append({'season_num': str(s), 'episodes': season_eps})
            series_meta = seasons

    return render_template('item_detail.html', item=item_details, series_meta=series_meta)


@app.route('/browse')
def browse():
    mode = request.args.get('m', 'movies')
    if mode not in ('movies', 'series', 'live'):
        mode = 'movies'
    cat_id = request.args.get('c', '')

    if mode == 'live':
        categories = xtream.live_categories()
        raw = xtream.live_streams(cat_id)
        items = [normalize_live_item(x) for x in raw[:250]]
    elif mode == 'series':
        categories = xtream.series_categories()
        raw = xtream.series_streams(cat_id)
        items = [normalize_series_item(x) for x in raw[:250]]
    else:
        categories = xtream.vod_categories()
        raw = xtream.vod_streams(cat_id)
        items = [normalize_vod_item(x) for x in raw[:250]]

    if isinstance(raw, list):
        raw.sort(key=newest_key, reverse=True)

    return render_template('browse.html', mode=mode, categories=categories, items=items, cat_id=str(cat_id))

@app.route('/api/series/<series_id>')
def series_details(series_id):
    data = xtream.series_info(series_id)
    result = {'id': series_id, 'seasons': []}
    episodes = data.get('episodes', {}) if isinstance(data, dict) else {}
    if not episodes:
        return jsonify(result)

    season_keys = sorted(episodes.keys(), key=lambda x: safe_int(str(x), 99999))
    for s in season_keys:
        eps = episodes.get(s, [])
        season = {'season_num': str(s), 'episodes': []}
        for ep in eps:
            eid = str(ep.get('id') or ep.get('episode_id') or '')
            ext = ep.get('container_extension', 'mp4')
            season['episodes'].append({
                'id': eid,
                'num': ep.get('episode_num') or '',
                'title': ep.get('title') or f'Bölüm {ep.get("episode_num") or ""}'.strip(),
                'url': build_stream_url('series', eid, ext),
            })
        result['seasons'].append(season)
    return jsonify(result)

@app.route('/search')
def search():
    q = request.args.get('q', '').strip().lower()
    out = {'results': []}
    if len(q) < 2:
        return jsonify(out)

    try:
        vod = xtream.vod_streams()
        series = xtream.series_streams()
        live = xtream.live_streams()

        results = []
        for x in vod[:300]:
            if q in (x.get('name', '').lower()):
                results.append(normalize_vod_item(x))
        for x in series[:250]:
            if q in (x.get('name', '').lower()):
                results.append(normalize_series_item(x))
        for x in live[:250]:
            if q in (x.get('name', '').lower()):
                results.append(normalize_live_item(x))

        out['results'] = results[:60]
    except Exception as e:
        print('SEARCH ERROR', e)

    return jsonify(out)

def resolve_api_mkv(api_url: str) -> str:
    try:
        r = session.get(api_url, timeout=10, allow_redirects=True)
        r.raise_for_status()
        text = r.text.strip()
        if not text:
            return ''
        # M3U veya düz url
        if '#EXTM3U' in text.upper():
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if strict_http_url(line):
                    return line
        # bazen tek satırda direkt mkv link
        first = text.splitlines()[0].strip()
        if strict_http_url(first):
            return first
    except Exception as e:
        print('resolve_api_mkv error', e)
    return ''


def compute_next_episode(series_id: str, item_id: str, title: str):
    if not series_id or not item_id:
        return ''
    data = xtream.series_info(series_id)
    episodes = data.get('episodes', {}) if isinstance(data, dict) else {}
    flat = []
    for season_num in sorted(episodes.keys(), key=lambda x: safe_int(str(x), 99999)):
        for ep in episodes.get(season_num, []):
            eid = str(ep.get('id') or ep.get('episode_id') or '')
            ext = ep.get('container_extension', 'mp4')
            flat.append({
                'id': eid,
                'title': ep.get('title') or '',
                'episode_num': str(ep.get('episode_num') or ''),
                'season_num': str(season_num),
                'url': build_stream_url('series', eid, ext)
            })
    for i, ep in enumerate(flat):
        if ep['id'] == str(item_id) and i + 1 < len(flat):
            nxt = flat[i + 1]
            base_title = title.split(' - ')[0] if title else 'Bölüm'
            next_title = f"{base_title} - S{nxt['season_num']}E{nxt['episode_num']}"
            return '/player?mode=series&id=' + quote(nxt['id'], safe='') + '&title=' + quote(next_title, safe='') + '&url=' + quote(nxt['url'], safe='') + '&series_id=' + quote(str(series_id), safe='')
    return ''

@app.route('/player')
def player():
    title = request.args.get('title', '')
    url = request.args.get('url', '')
    api_url = request.args.get('api_url', '')
    item_id = request.args.get('id', '')
    mode = request.args.get('mode', 'movies')
    series_id = request.args.get('series_id', '')
    direct = request.args.get('direct', '0') in ('1', 'true', 'yes')

    if api_url:
        resolved = resolve_api_mkv(api_url)
        if not resolved:
            return 'API-den link alinamadi', 400
        url = resolved

    if not url and item_id:
        if mode == 'live':
            url = build_stream_url('live', item_id, 'ts')
        elif mode == 'series':
            url = build_stream_url('series', item_id, 'mp4')
        else:
            url = build_stream_url('movies', item_id, 'mp4')

    if not strict_http_url(url):
        return 'Oynatilacak URL eksik veya gecersiz', 400

    if direct:
        return redirect('/proxy?url=' + quote(url, safe=''))

    try:
        head_resp = session.head(url, allow_redirects=True, timeout=10)
        if head_resp.status_code == 200 and strict_http_url(head_resp.url):
            url = head_resp.url
    except Exception:
        pass

    playback_url = '/proxy?url=' + quote(url, safe='')
    next_episode_url = compute_next_episode(series_id, item_id, title) if mode == 'series' else ''

    prev_live_url = ''
    next_live_url = ''
    prev_live_title = ''
    next_live_title = ''

    if mode == 'live' and item_id:
        try:
            raw_live = xtream.live_streams()
            if isinstance(raw_live, list):
                live_items = [normalize_live_item(x) for x in raw_live]
                idx = next((i for i, ch in enumerate(live_items) if str(ch.get('id')) == str(item_id)), -1)
                if idx != -1 and live_items:
                    prev_item = live_items[idx - 1] if idx > 0 else live_items[-1]
                    next_item = live_items[idx + 1] if idx < len(live_items) - 1 else live_items[0]
                    prev_live_url = '/player?mode=live&id={}&title={}&url={}'.format(
                        quote(str(prev_item.get('id', '')), safe=''),
                        quote(str(prev_item.get('title', 'Kanal')), safe=''),
                        quote(str(prev_item.get('url', '')), safe='')
                    )
                    next_live_url = '/player?mode=live&id={}&title={}&url={}'.format(
                        quote(str(next_item.get('id', '')), safe=''),
                        quote(str(next_item.get('title', 'Kanal')), safe=''),
                        quote(str(next_item.get('url', '')), safe='')
                    )
                    prev_live_title = str(prev_item.get('title', ''))
                    next_live_title = str(next_item.get('title', ''))
        except Exception:
            pass

    return render_template(
        'player.html',
        url=url,
        playback_url=playback_url,
        title=title,
        item_id=item_id,
        mode=mode,
        series_id=series_id,
        next_episode_url=next_episode_url,
        prev_live_url=prev_live_url,
        next_live_url=next_live_url,
        prev_live_title=prev_live_title,
        next_live_title=next_live_title
    )

_M3U8_URI_RE = re.compile(r'URI="([^"]+)"')

def rewrite_m3u8(body: str, source_url: str) -> str:
    def repl(match):
        uri = match.group(1)
        full = urljoin(source_url, uri)
        return f'URI="/proxy?url={quote(full, safe="")}"'
    body = _M3U8_URI_RE.sub(repl, body)
    lines = []
    for line in body.splitlines():
        s = line.strip()
        if not s or s.startswith('#'):
            lines.append(line)
        else:
            lines.append('/proxy?url=' + quote(urljoin(source_url, s), safe=''))
    return '\n'.join(lines)



@app.route('/proxy')
def proxy():
    target = (request.args.get('url') or '').strip()
    if not strict_http_url(target):
        return 'Gecersiz URL', 400

    # Frontend'in proxy icine tekrar proxy sarmasini engelle
    if '/proxy?url=' in target or '/proxy_stream?url=' in target:
        return 'Nested proxy URL blocked', 400

    base_headers = {
        'User-Agent': request.headers.get(
            'User-Agent',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        ),
        'Accept': 'video/webm,video/mp4,video/*;q=0.9,application/octet-stream;q=0.8,*/*;q=0.5',
        'Accept-Language': request.headers.get('Accept-Language', 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7'),
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': target,
        'Origin': '',
    }
    if request.headers.get('Range'):
        base_headers['Range'] = request.headers.get('Range')

    candidate_headers = [
        base_headers,
        {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'video/*, application/octet-stream, */*;q=0.1',
            'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'Referer': target,
            'Origin': '',
        },
        {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0',
            'Accept': '*/*',
            'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'Referer': target,
            'Origin': '',
        }
    ]

    if request.headers.get('Range'):
        for c in candidate_headers:
            c['Range'] = request.headers.get('Range')

    def is_video_content_type(content_type):
        ct = (content_type or '').lower()
        return (
            ct.startswith('video/')
            or 'application/octet-stream' in ct
            or 'matroska' in ct
            or 'mp4' in ct
            or 'mpegurl' in ct
            or 'mp2t' in ct
        )

    resolved_target = target
    try:
        head_resp = session.head(
            target,
            allow_redirects=True,
            timeout=8,
            headers={
                'User-Agent': base_headers['User-Agent'],
                'Accept': '*/*',
                'Referer': target
            }
        )
        if head_resp.status_code in (200, 206) and strict_http_url(head_resp.url):
            resolved_target = head_resp.url
    except Exception:
        resolved_target = target

    if resolved_target != target:
        print('proxy: redirected target resolved', target, '->', resolved_target)
    target = resolved_target

    def fetch_target(tgt):
        upstream = None
        for idx, hdrs in enumerate(candidate_headers):
            try:
                upstream = session.get(tgt, stream=True, timeout=(10, 180), headers=hdrs, allow_redirects=True)
            except requests.RequestException as exc:
                print('proxy attempt', idx + 1, 'exception', exc, 'target', tgt)
                upstream = None
                continue

            ct = upstream.headers.get('Content-Type', '').lower()
            print('proxy attempt', idx + 1, 'status', upstream.status_code, 'url', upstream.url, 'ct', ct, 'target', tgt)

            if upstream.status_code >= 400:
                preview = ''
                try:
                    preview = upstream.text[:250]
                except Exception:
                    preview = '<preview unavailable>'
                print('proxy upstream error preview repr:', repr(preview))
                upstream.close()
                upstream = None
                continue

            if upstream.status_code in (200, 206):
                if not is_video_content_type(ct) and '.m3u8' not in upstream.url.lower():
                    preview = ''
                    try:
                        preview = upstream.text[:250]
                    except Exception:
                        preview = '<preview unavailable>'
                    print('proxy non-video preview repr:', repr(preview))
                    upstream.close()
                    upstream = None
                    continue
                return upstream
        return None

    upstream = fetch_target(target)
    if upstream is None:
        return 'Upstream unavailable / invalid content-type', 502

    content_type = upstream.headers.get('Content-Type', '')
    path = urlparse(upstream.url or target).path.lower()
    is_m3u8 = '.m3u8' in path or 'application/vnd.apple.mpegurl' in content_type or 'application/x-mpegurl' in content_type

    if is_m3u8:
        try:
            text = upstream.text
            rewritten = rewrite_m3u8(text, upstream.url)
            upstream.close()
            return Response(rewritten, status=200, mimetype='application/vnd.apple.mpegurl', headers={'Cache-Control': 'no-store'})
        except Exception as e:
            try:
                upstream.close()
            except Exception:
                pass
            return f'Playlist hatasi: {e}', 502

    passthrough = ['Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Cache-Control', 'ETag', 'Last-Modified']
    response_headers = {h: upstream.headers[h] for h in passthrough if h in upstream.headers}
    response_headers['Cache-Control'] = 'no-store'

    def generate():
        try:
            for chunk in upstream.iter_content(chunk_size=64 * 1024):
                if chunk:
                    yield chunk
        except (ChunkedEncodingError, RequestsConnectionError, OSError) as e:
            print('PROXY STREAM WARNING', target, e)
            return
        finally:
            try:
                upstream.close()
            except Exception:
                pass

    return Response(stream_with_context(generate()), status=upstream.status_code, headers=response_headers)

@app.route('/proxy_stream')
def proxy_stream():
    return proxy()

@app.route('/cache/clear')

def clear_cache():
    cache.clear()
    return jsonify({'ok': True, 'cache_items': cache.size()})


@app.route('/continue', methods=['GET'])
def continue_list():
    return jsonify(list_items())

@app.route('/continue', methods=['POST'])
def continue_save():
    data = request.json or {}
    save_progress(data)
    return jsonify({'ok':True})

@app.route('/api/continue')
def api_continue():
    try:
        from services.continue_watch import list_items
        return jsonify({'items': list_items()})
    except Exception as e:
        return jsonify({'items': [], 'error': str(e)})

@app.route('/api/epg/<channel_id>')
def api_epg(channel_id):
    try:
        from providers.epg import EPGProvider
        epg = EPGProvider().now_next(channel_id)
        return jsonify(epg)
    except Exception as e:
        return jsonify({'now': '', 'next': '', 'error': str(e)})

@app.route('/health')
def health():
    return jsonify({'ok': True, 'providers': providers.names(), 'cache_items': cache.size()})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, threaded=True, debug=False)
