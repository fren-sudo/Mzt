(function(){
  'use strict';

  var video = document.getElementById('video');
  var cfg = window.playerConfig || {};
  if(!video) return;
  if(cfg.mode === 'live') return;

  var lastSentAt = 0;
  var sending = false;
  var SAVE_INTERVAL = 20000;

  function canSend(force){
    if(sending) return false;
    if(video.readyState < 1) return false;
    if(!video.duration || !isFinite(video.duration)) return false;
    var now = Date.now();
    if(!force && now - lastSentAt < SAVE_INTERVAL) return false;
    return true;
  }

  function sendProgress(force){
    if(!canSend(force)) return;
    lastSentAt = Date.now();
    sending = true;

    fetch('/continue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        item_id: cfg.itemId || '',
        mode: cfg.mode || '',
        title: cfg.title || '',
        current_time: Math.floor(video.currentTime || 0),
        duration: Math.floor(video.duration || 0),
        poster: cfg.poster || ''
      })
    }).catch(function(){}).finally(function(){
      setTimeout(function(){ sending = false; }, 1000);
    });
  }

  video.addEventListener('timeupdate', function(){ sendProgress(false); });
  video.addEventListener('pause', function(){ sendProgress(true); });
  video.addEventListener('ended', function(){ sendProgress(true); });
  window.addEventListener('beforeunload', function(){ sendProgress(true); });
})();