(function () {
  'use strict';
  if (window.__detailNavFixBound) return;
  window.__detailNavFixBound = true;

  function visible(el){
    return !!(el && el.offsetParent !== null && !el.hidden && !el.disabled);
  }

  function collect(root){
    return Array.prototype.slice.call(
      (root || document).querySelectorAll('.selector, .detail-btn, .episode-card, .season-chip, .related-card, button, a')
    ).filter(visible);
  }

  function prepare(root){
    var items = collect(root);
    items.forEach(function(el){
      if(!el.classList.contains('selector')) el.classList.add('selector');
      if(!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    });
    return items;
  }

  function refresh(){
    var root = document.querySelector('.detail-page') || document.querySelector('.item-detail-page') || document.body;
    var items = prepare(root);
    if(!items.length) return;
    if(window.navigatorInstance && typeof window.navigatorInstance.setCollection === 'function'){
      window.navigatorInstance.setCollection(items);
      var focused = document.activeElement && items.indexOf(document.activeElement) !== -1 ? document.activeElement : items[0];
      window.navigatorInstance.focus(focused);
    } else {
      try { items[0].focus(); } catch(e) {}
    }
  }

  document.addEventListener('DOMContentLoaded', refresh);
  window.addEventListener('load', refresh);
  setTimeout(refresh, 200);

  document.addEventListener('keydown', function(e){
    if(!(document.querySelector('.detail-page') || document.querySelector('.item-detail-page'))) return;
    if(e.key === 'Enter' || e.keyCode === 13){
      var focused = document.querySelector('.selector.focus') || document.activeElement;
      if(!focused) return;
      var href = focused.getAttribute('href') || focused.dataset.href;
      if(href){
        e.preventDefault();
        window.location.href = href;
      }
    }
  }, true);
})();