(function(){
function render(items){
    const rail=document.getElementById("nexusContinueRail");
    if(!rail) return;

    const body=rail.querySelector(".rail__body");
    body.innerHTML="";

    items.forEach(function(i){
        const el=document.createElement("article");
        el.className="poster-card selector continue-card";
        el.tabIndex=0;
        el.dataset.action="play";
        el.dataset.mode=i.mode;
        el.dataset.id=i.id;
        el.dataset.title=i.title;
        el.innerHTML=`
            <div class="poster-card__meta">
              <div class="poster-card__title">${i.title}</div>
              <div class="poster-card__sub">Devam: ${i.pos || i.current_time || 0}s</div>
            </div>
        `;
        body.appendChild(el);
    });

    rail.hidden=false;
    if(window.patchContinueRailFocus) window.patchContinueRailFocus();
    if(window.navigatorInstance && typeof window.navigatorInstance.setCollection === 'function'){
      try{
        var all=Array.prototype.slice.call(document.querySelectorAll('.selector')).filter(function(el){
          return el.offsetParent !== null && !el.hidden && !el.disabled;
        });
        window.navigatorInstance.setCollection(all);
      }catch(e){}
    }
}
fetch("/api/continue").then(r=>r.json()).then(d=>render(d.items||[])).catch(function(){});
})();