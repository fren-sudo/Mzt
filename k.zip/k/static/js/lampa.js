function initLampa() {
  const cards = document.querySelectorAll('.lampa-card');
  const tabs = document.querySelectorAll('.lampa-tab');
  const sections = document.querySelectorAll('.lampa-row');

  function setGroup(group) {
    sections.forEach((section) => {
      const type = section.dataset.group || 'all';
      section.hidden = group !== 'all' && type !== group;
    });

    tabs.forEach((tab) => {
      tab.classList.toggle('active', tab.dataset.group === group);
    });

    if (group === 'all') {
      document.querySelectorAll('.lampa-row').forEach((s) => (s.hidden = false));
    }
  }

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => setGroup(tab.dataset.group));
  });

  setGroup('all');

  if (!cards || cards.length === 0) {
    return;
  }

  let current = 0;
  cards.forEach((card, idx) => {
    card.dataset.index = idx;
    card.addEventListener('click', () => {
      card.classList.add('active');
    });
  });

  function focusCard(idx) {
    const normalized = Math.max(0, Math.min(cards.length - 1, idx));
    cards[normalized].focus();
    current = normalized;
  }

  document.addEventListener('keydown', (event) => {
    if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown', 'Enter'].includes(event.key)) {
      event.preventDefault();
    }

    if (event.key === 'ArrowRight') {
      focusCard(current + 1);
      return;
    }

    if (event.key === 'ArrowLeft') {
      focusCard(current - 1);
      return;
    }

    if (event.key === 'ArrowDown') {
      focusCard(current + 5);
      return;
    }

    if (event.key === 'ArrowUp') {
      focusCard(current - 5);
      return;
    }

    if (event.key === 'Enter') {
      cards[current].click();
      return;
    }
  });

  focusCard(0);
}
