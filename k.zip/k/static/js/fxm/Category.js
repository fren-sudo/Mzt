/**
 * Created by moritz on 12/11/17.
 */
(function () {
    /**
     * @param data.portal               FxmModule.Portal
     * @param data.portal.appIconType   String
     * @param data.ID                   int
     * @constructor
     */
    FxmModule.Category = function (data) {
        var _getAppsUrl = "/frontend/modules/ajax/GetApps.php";

        var self = {};
        self.data = data;
        this.data = data;

        this.lastApps = null;
        this.lastOptions = null;
        this.type = "Category";

        /**
         * @param options
         * @param callback
         * @param templateName
         */
        this.getApps = function (options, callback, templateName, watchlistId) {
            var template = FxmModule.getTemplateByName(templateName);

            if (this.lastApps !== null && this.lastOptions === options) {
                FxmModule.checkCallback(callback, this.lastApps);
            } else {
                var finalOptions = $.extend({
                    "portalId": this.data.portal.portalId,
                    "DeviceId": this.data.portal.device.deviceId,
                    "categoryId": this.data.ID
                }, options);

                FxmModule.ajax(_getAppsUrl, "post", finalOptions, $.proxy(function (msg) {
                    msg = _processApps(eval("(" + msg + ")"), this.data.portal.appIconType, this.data.portal.appScreenshotType, template, watchlistId);

                    this.lastOptions = options;
                    this.lastApps = msg;

                    FxmModule.checkCallback(callback, msg);
                }, this));
            }
        };

        /**
         * @param data
         * @param iconType
         * @param template
         * @returns {*}
         * @private
         */
        var _processApps = function (data, iconType, screenshotType, template, watchlistId) {
            if (data !== null) {
                var dataLength = data.length,
                    processedData = [];

                for (var i = 0; i < dataLength; i++) {
                    data[i].iconType = iconType;
                    data[i].screenshotType = screenshotType;

                    if (watchlistId !== null) {
                        data[i].watchlistId = watchlistId;
                    }

                    var app = new FxmModule.App(data[i]);

                    if (template !== null) {
                        app.setTemplate(template);
                    }

                    processedData.push(app);
                }

                return processedData;
            }

            return false;
        };
    };
})(window);