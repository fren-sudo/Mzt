/**
 * Created by moritz on 12/21/17.
 */
(function () {
    /**
     * @param data
     * @constructor
     */
    FxmModule.Content = function (data) {
        /* Online Content (Youtube/Dailymotion) */
        if (data.content_partner_id) {
            if (String(data.content_partner_id).substr(0, 11) === "dailymotion") {
                data.id = "dm_" + data.id;
            } else if (String(data.content_partner_id).substr(0, 7) === "youtube") {
                data.id = "yt_" + data.id;
            }
        }

        this.data = data;
        this.template = null;
        this.html = null;
        this.isOnWatchlist = false;

        var self = this;

        var _maximumIdCount = 42;

        /**
         * @param storageId
         * @param callback
         * @private
         */
        var _store = function (storageId, callback) {
            var value = FxmModule.getStoredData(storageId),
                id = _getId(self.data);

            value = (value) ? _checkDoubleId(value, id) : id;

            FxmModule.store(storageId, value, callback);
        };

        /**
         * @param idString
         * @param id
         * @returns {string}
         * @private
         */
        var _checkDoubleId = function (idString, id) {
            id = id.toString();

            var idArray = idString.split(","),
                idLength = idArray.length,
                newString = "",
                startingIndex = 0;

            if (idLength > _maximumIdCount) {
                startingIndex = idLength - _maximumIdCount;
            }

            for (var i = startingIndex; i < idLength; i++) {
                var currentId = idArray[i].toString();

                if (currentId !== id) {
                    newString += newString === "" ? currentId : "," + currentId;
                }
            }

            newString += newString === "" ? id : "," + id;

            return newString;
        };

        /**
         * @param data
         * @returns {string|string|string|string|string|string|*}
         * @private
         */
        var _getId = function (data) {
            /* App */
            if (typeof data.id === "undefined") {
                return data.ID;
            }

            /* Foxxalicious/Online Content */
            return data.id;
        };

        /**
         * @param storageId
         * @returns {*}
         * @private
         */
        var _getStoredIdArray = function (storageId) {
            var value = FxmModule.getStoredData(storageId);

            if (value) {
                return value.split(",");
            }

            return false;
        };

        /**
         * @param callback
         * @param watchlistId
         * @private
         */
        var _addToWatchlist = function (callback, watchlistId) {
            if (typeof watchlistId === "undefined") {
                watchlistId = self.watchlistId;
            }

            _store(watchlistId, function () {
                FxmModule.checkCallback(callback, true);
            });
        };

        /**
         * @param callback
         * @param watchlistId
         * @private
         */
        var _removeFromWatchlist = function (callback, watchlistId) {
            if (typeof watchlistId === "undefined") {
                watchlistId = self.watchlistId;
            }

            var value = FxmModule.getStoredData(watchlistId),
                id = _getId(self.data),
                idArray = value.split(","),
                idArrayLength = idArray.length,
                newString = "";

            for (var i = 0; i < idArrayLength; i++) {
                if (idArray[i] !== id) {
                    newString += (newString === "") ? idArray[i] : "," + idArray[i];
                }
            }

            FxmModule.store(watchlistId, newString, function () {
                FxmModule.checkCallback(callback, true);
            });
        };

        /* Timeout of 0ms to "pause" the JavaScript execution to let the rendering threads catch up */
        setTimeout(function () {
            var watchlistIdArray = _getStoredIdArray(self.watchlistId);

            if (watchlistIdArray) {
                if ($.inArray(_getId(self.data), watchlistIdArray) !== -1) {
                    self.isOnWatchlist = true;
                }
            }
        }, 0);

        this.open = function () {
            _store(self.storageId, function () {
                self.openUrl();
            });
        };

        /**
         * @param callback
         */
        this.watchlistAction = function (callback, watchlistId) {
            if (self.isOnWatchlist) {
                _removeFromWatchlist(function () {
                    self.isOnWatchlist = false;
                    FxmModule.checkCallback(callback, true);
                }, watchlistId);
            } else {
                _addToWatchlist(function () {
                    self.isOnWatchlist = true;
                    FxmModule.checkCallback(callback, true);
                }, watchlistId);
            }
        };

        /**
         * @param template
         */
        this.setTemplate = function (template) {
            this.template = template;
        };

        /**
         * @returns {null}
         */
        this.getHtml = function () {
            if (this.html !== null) {
                return this.html;
            } else {
                if (this.template !== null) {
                    this.html = FxmModule.getHtml(this.data, this.template);
                    return this.html;
                }
            }
        };
    };
})(window);