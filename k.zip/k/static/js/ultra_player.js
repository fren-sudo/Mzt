
(function(){

function attachFailover(video, cfg){
    if(!cfg || !cfg.backups) return
    video.addEventListener("error", function(){
        if(cfg.backups.length){
            var next = cfg.backups.shift()
            var target = (window.buildStreamUrl ? window.buildStreamUrl(next) : next)
            video.src = target
            video.play()
        }
    })
}

window.attachUltraPlayer=function(video,cfg){
    attachFailover(video,cfg)
}

})();
