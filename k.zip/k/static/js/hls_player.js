
(function(){

function attachHLS(video,url){
    var normalizedUrl = (window.buildStreamUrl ? window.buildStreamUrl(url) : url)
    if(video.canPlayType('application/vnd.apple.mpegurl')){
        video.src = normalizedUrl
    }else if(window.Hls){
        var hls = new Hls()
        hls.loadSource(normalizedUrl)
        hls.attachMedia(video)
    }else{
        video.src = normalizedUrl
    }
}

window.attachHLSPlayer = attachHLS

})();
