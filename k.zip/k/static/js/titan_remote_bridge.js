(function(){
  'use strict';
  if(!window.TITAN_REMOTE_BRIDGE){
    window.TITAN_REMOTE_BRIDGE = {
      ready: true,
      hasFXM: !!(window.fxm || window.FXM || window.fxmfw),
      note: 'Reference TV navigation files loaded when available'
    };
  }
})();