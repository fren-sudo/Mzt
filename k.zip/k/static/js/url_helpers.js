(function(global){
  'use strict';

  function normalizeImageUrl(url){
    if(!url) return '';
    var value = String(url).trim();
    if(value.indexOf('//') === 0) return 'https:' + value;
    if(value.toLowerCase().indexOf('http://') === 0) return 'https://' + value.substr(7);
    return value;
  }

  function buildStreamUrl(url){
    if(!url) return '';
    return '/proxy_stream?url=' + encodeURIComponent(url);
  }

  function chooseBestArtwork(item){
    if(!item) return '/static/img/placeholder.svg';
    var keys = ['logo','stream_icon','cover','cover_big','movie_image','poster','backdrop_path','img'];
    for(var i=0;i<keys.length;i++){
      var value = item[keys[i]];
      if(value && String(value).indexOf('logo.uixtreamreseller.com') === -1){
        return normalizeImageUrl(value);
      }
    }
    return '/static/img/placeholder.svg';
  }

  function attachImageFallback(imgEl, fallbackUrl){
    if(!imgEl) return;
    var triedFallback = false;
    imgEl.onerror = function(){
      if(triedFallback){
        imgEl.onerror = null;
        imgEl.src = '/static/img/placeholder.svg';
        return;
      }
      triedFallback = true;
      imgEl.src = fallbackUrl || '/static/img/placeholder.svg';
    };
  }

  global.normalizeImageUrl = normalizeImageUrl;
  global.buildStreamUrl = buildStreamUrl;
  global.chooseBestArtwork = chooseBestArtwork;
  global.attachImageFallback = attachImageFallback;
})(window);
